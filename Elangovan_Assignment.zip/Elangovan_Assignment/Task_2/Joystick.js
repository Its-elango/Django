import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';

const socket = io('http://localhost:5000', { query: { token: 'your-jwt-token' } });

const Joystick = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });

  // Function to send joystick data to the server via WebSocket
  const sendJoystickData = (x, y) => {
    socket.emit('joystick_data', JSON.stringify({ x, y }));
  };
  // Function to handle joystick movement
  const handleJoystickMove = (e) => {
    const rect = e.target.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const x = e.clientX - centerX;
    const y = e.clientY - centerY;

    setPosition({ x, y });
    sendJoystickData(x, y);
  };
  // Event listeners for joystick interactions
  useEffect(() => {
    const joystickContainer = document.getElementById('joystick-container');
    joystickContainer.addEventListener('mousemove', handleJoystickMove);
    joystickContainer.addEventListener('mousedown', handleJoystickMove);

    // Clean up the event listeners on component unmount
    return () => {
      joystickContainer.removeEventListener('mousemove', handleJoystickMove);
      joystickContainer.removeEventListener('mousedown', handleJoystickMove);
    };
  }, []);
  return (
    <div id="joystick-container" style={{ width: '200px', height: '200px', position: 'relative' }}>
      <div
        style={{
          width: '50px',
          height: '50px',
          background: 'red',
          borderRadius: '50%',
          position: 'absolute',
          top: 100 + position.y + 'px',
          left: 100 + position.x + 'px',
        }}
      />
    </div>
  );
};

export default Joystick;