import React from 'react';
import io from 'socket.io-client';
import axios from 'axios';

const socket = io('http://localhost:5000', { query: { token: 'your-jwt-token' } });

class App extends React.Component {
  componentDidMount() {
    // Assuming you have a function to get joystick data from your joystick component
    // Replace 'getJoystickData()' with the actual function name.
    setInterval(() => {
      const joystickData = getJoystickData();
      socket.emit('joystick_data', joystickData);
    }, 500);
  }

  handleLogin = async () => {
    // Replace 'your-username' and 'your-password' with the actual user credentials
    const response = await axios.post('http://localhost:3000/login', {
      username: 'your-username',
      password: 'your-password',
    });
    const token = response.data.token;
    socket.io.opts.query = { token };
    socket.connect();
  };
  handleProtectedRequest = async () => {
    try {
      const response = await axios.get('http://localhost:3000/protected', {
        headers: { Authorization: socket.io.opts.query.token },
      });
      console.log(response.data);
    } catch (error) {
      console.error('Error accessing protected endpoint:', error.message);
    }
  };
  render() {
    return (
      <div>
        <button onClick={this.handleLogin}>Login</button>
        <button onClick={this.handleProtectedRequest}>Access Protected Endpoint</button>
      </div>
    );
  }
}

export default App;