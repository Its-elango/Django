const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');

const app = express();

const secretKey = 'your-secret-key'; // Replace this with your secret key for JWT

// Middleware to verify JWT token for RESTful endpoints
function verifyToken(req, res, next) {
  const token = req.headers.authorization;
  if (!token) return res.status(401).json({ error: 'Unauthorized: Missing token' });

  jwt.verify(token, secretKey, (err, decoded) => {
    if (err) return res.status(401).json({ error: 'Unauthorized: Invalid token' });
    req.userId = decoded.userId;
    next();
  });
}
app.use(bodyParser.json());

// Sample endpoint for user login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  // Add your authentication logic here (e.g., checking username and password)
  // If authentication is successful, generate a JWT token and send it back to the client
  const token = jwt.sign({ userId: 'your-user-id' }, secretKey, { expiresIn: '1h' });
  res.json({ token });
});

// Protected endpoint that requires authentication
app.get('/protected', verifyToken, (req, res) => {
  // If the token is valid, the user is authenticated
  // You can perform actions based on the authenticated user, such as fetching user-specific data
  res.json({ message: 'Protected endpoint accessed successfully' });
});
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`RESTful API server listening on port ${PORT}`);
});