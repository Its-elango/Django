const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const jwt = require('jsonwebtoken');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

const secretKey = 'your-secret-key'; // Replace this with your secret key for JWT

// Middleware to verify JWT token for WebSocket connection
function verifyToken(socket, next) {
  const token = socket.handshake.query.token;
  jwt.verify(token, secretKey, (err, decoded) => {
    if (err) return next(new Error('Authentication error'));
    socket.userId = decoded.userId;
    next();
  });
}
io.on('connection', (socket) => {
  console.log(`User connected with ID: ${socket.userId}`);

  // Handle incoming joystick data
  socket.on('joystick_data', (data) => {
    // Process the data received from the React application
    console.log(`Joystick data received: ${data}`);
    // You can perform further actions here based on the joystick data received.
    // For example, you can broadcast this data to other connected clients.
  });

  socket.on('disconnect', () => {
    console.log(`User disconnected with ID: ${socket.userId}`);
  });
});

const PORT = 5000;
server.listen(PORT, () => {
  console.log(`WebSocket server listening on port ${PORT}`);
});